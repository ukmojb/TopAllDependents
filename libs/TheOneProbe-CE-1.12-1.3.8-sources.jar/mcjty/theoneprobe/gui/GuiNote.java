package mcjty.theoneprobe.gui;

import mcjty.theoneprobe.TheOneProbe;
import mcjty.theoneprobe.config.Config;
import mcjty.theoneprobe.rendering.RenderHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

import java.io.IOException;

import static mcjty.theoneprobe.config.Config.*;
import static net.minecraft.util.text.TextFormatting.BOLD;
import static net.minecraft.util.text.TextFormatting.GREEN;

public class GuiNote extends GuiScreen {
    public static final int BUTTON_HEIGHT = 16;
    private static final int WIDTH = 256;
    private static final int HEIGHT = 160;
    private static final int BUTTON_WIDTH = 70;
    private static final int BUTTON_MARGIN = 80;
    private static final ResourceLocation background = new ResourceLocation(TheOneProbe.MODID, "textures/gui/note.png");
    private int guiLeft;
    private int guiTop;
    private int hitX;
    private int hitY;

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        super.initGui();
        guiLeft = (this.width - WIDTH) / 2;
        guiTop = (this.height - HEIGHT) / 2;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        mc.getTextureManager().bindTexture(background);
        drawTexturedModalRect(guiLeft, guiTop, 0, 0, WIDTH, HEIGHT);
        int x = guiLeft + 5;
        int y = guiTop + 8;
        RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.title") + TextFormatting.GOLD + " " + tr("top.note.mod_name"));
        y += 10;
        y += 10;

        RenderHelper.renderText(Minecraft.getMinecraft(), x, y, BOLD + tr("top.note.intro.1"));
        y += 10;
        RenderHelper.renderText(Minecraft.getMinecraft(), x, y, BOLD + tr("top.note.intro.2"));
        y += 10;

        y += 10;
        switch (Config.needsProbe) {
            case PROBE_NEEDED:
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.needed.1"));
                y += 10;
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.needed.2"));
                y += 10;
                y += 16;
                y = setInConfig(x, y);
                break;
            case PROBE_NOTNEEDED:
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.not_needed.1"));
                y += 10;
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.not_needed.2"));
                y += 10;
                y += 16;
                y = setInConfig(x, y);
                break;
            case PROBE_NEEDEDFOREXTENDED:
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.extended.1"));
                y += 10;
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.extended.2"));
                y += 10;
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.extended.3"));
                y += 10;
                y += 6;
                y = setInConfig(x, y);
                break;
            case PROBE_NEEDEDHARD:
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.hard_needed.1"));
                y += 10;
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.hard_needed.2"));
                y += 10;
                RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.hard_needed.3"));
                y += 10;
                break;
        }

        y += 10;

        RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.footer.1"));
        y += 10;
        RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.footer.2"));
        y += 10;
        RenderHelper.renderText(Minecraft.getMinecraft(), x, y, tr("top.note.footer.3"));
        y += 10;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        mouseX += guiLeft;
        mouseY += guiTop;
        if (mouseY >= hitY && mouseY < hitY + BUTTON_HEIGHT) {
            if (mouseX >= hitX && mouseX < hitX + BUTTON_WIDTH) {
                Config.setProbeNeeded(PROBE_NEEDED);
            } else if (mouseX >= hitX + BUTTON_MARGIN && mouseX < hitX + BUTTON_WIDTH + BUTTON_MARGIN) {
                Config.setProbeNeeded(PROBE_NOTNEEDED);
            } else if (mouseX >= hitX + BUTTON_MARGIN * 2 && mouseX < hitX + BUTTON_WIDTH + BUTTON_MARGIN * 2) {
                Config.setProbeNeeded(PROBE_NEEDEDFOREXTENDED);
            }
        }
    }

    private int setInConfig(int x, int y) {
        RenderHelper.renderText(Minecraft.getMinecraft(), x, y, BOLD + "" + GREEN + tr("top.note.change_here"));
        y += 10;

        hitY = y + guiTop;
        hitX = x + guiLeft;
        drawRect(x, y, x + BUTTON_WIDTH, y + BUTTON_HEIGHT, 0xff000000);
        RenderHelper.renderText(Minecraft.getMinecraft(), x + 3, y + 4, tr("top.note.button.needed"));
        x += BUTTON_MARGIN;

        drawRect(x, y, x + BUTTON_WIDTH, y + BUTTON_HEIGHT, 0xff000000);
        RenderHelper.renderText(Minecraft.getMinecraft(), x + 3, y + 4, tr("top.note.button.not_needed"));
        x += BUTTON_MARGIN;

        drawRect(x, y, x + BUTTON_WIDTH, y + BUTTON_HEIGHT, 0xff000000);
        RenderHelper.renderText(Minecraft.getMinecraft(), x + 3, y + 4, tr("top.note.button.extended"));
        x += BUTTON_MARGIN;

        y += BUTTON_HEIGHT - 4;
        return y;
    }

    private static String tr(String key) {
        return I18n.format(key);
    }

}
