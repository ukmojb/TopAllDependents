package mcjty.theoneprobe.apiimpl.client;

import mcjty.theoneprobe.Tools;
import mcjty.theoneprobe.api.IProgressStyle;
import mcjty.theoneprobe.apiimpl.elements.ElementProgress;
import mcjty.theoneprobe.config.Config;
import mcjty.theoneprobe.rendering.RenderHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

public class ElementProgressRender {

    private static final ResourceLocation ICONS = new ResourceLocation("textures/gui/icons.png");

    public static void render(IProgressStyle style, long current, long max, int x, int y, int w, int h) {
        if (style.isLifeBar()) {
            renderLifeBar(current, x, y, w, h);
        } else if (style.isArmorBar()) {
            renderArmorBar(current, x, y, w, h);
        } else if (Config.isJadeTheme()) {
            renderJadeBar(style, current, max, x, y, w, h);
        } else {
            renderDefaultBar(style, current, max, x, y, w, h);
        }

        if (style.isShowText()) {
            String prefix = Tools.applyTextStyles(style.getPrefixComponent().getFormattedText());
            String suffix = Tools.applyTextStyles(style.getSuffixComponent().getFormattedText());
            RenderHelper.renderText(Minecraft.getMinecraft(), x + 3, y + 2, prefix + ElementProgress.format(current, style.getNumberFormat(), suffix));
        }
    }

    private static void renderDefaultBar(IProgressStyle style, long current, long max, int x, int y, int w, int h) {
        RenderHelper.drawThickBeveledBox(x, y, x + w, y + h, 1, style.getBorderColor(), style.getBorderColor(), style.getBackgroundColor());
        fillBar(style, current, max, x, y, w, h);
    }

    private static void renderJadeBar(IProgressStyle style, long current, long max, int x, int y, int w, int h) {
        int borderColor = style.getBorderColor() == 0 ? 0xFF383838 : style.getBorderColor();
        int backgroundColor = style.getBackgroundColor() == 0 ? 0xFF242424 : style.getBackgroundColor();
        RenderHelper.drawThickBeveledBox(x, y, x + w, y + h, 1, borderColor, borderColor, backgroundColor);
        fillBar(style, current, max, x, y, w, h);
    }

    private static void fillBar(IProgressStyle style, long current, long max, int x, int y, int w, int h) {
        if (current <= 0 || max <= 0) {
            return;
        }

        int dx = (int) Math.min((current * (w - 2) / max), w - 2);
        if (dx <= 0) {
            return;
        }

        if (style.getFilledColor() == style.getAlternatefilledColor()) {
            RenderHelper.drawThickBeveledBox(x + 1, y + 1, x + dx + 1, y + h - 1, 1, style.getFilledColor(), style.getFilledColor(), style.getFilledColor());
        } else {
            for (int xx = x + 1; xx <= x + dx + 1; xx++) {
                int color = (xx & 1) == 0 ? style.getFilledColor() : style.getAlternatefilledColor();
                RenderHelper.drawVerticalLine(xx, y + 1, y + h - 1, color);
            }
        }
    }

    private static void renderLifeBar(long current, int x, int y, int w, int h) {
        RenderHelper.setOverlayColor();
        Minecraft.getMinecraft().getTextureManager().bindTexture(ICONS);
        if (current * 4 >= w) {
            // Shortened view
            RenderHelper.drawTexturedModalRectInset(x, y, 52, 0, 9, 9);
            RenderHelper.renderText(Minecraft.getMinecraft(), x + 12, y, TextFormatting.WHITE + String.valueOf((current / 2)));
        } else {
            for (int i = 0; i < current / 2; i++) {
                RenderHelper.drawTexturedModalRectInset(x, y, 52, 0, 9, 9);
                x += 8;
            }
            if (current % 2 != 0) {
                RenderHelper.drawTexturedModalRectInset(x, y, 61, 0, 9, 9);
            }
        }
    }

    private static void renderArmorBar(long current, int x, int y, int w, int h) {
        RenderHelper.setOverlayColor();
        Minecraft.getMinecraft().getTextureManager().bindTexture(ICONS);
        if (current * 4 >= w) {
            // Shortened view
            RenderHelper.drawTexturedModalRect(x, y, 43, 9, 9, 9);
            RenderHelper.renderText(Minecraft.getMinecraft(), x + 12, y, TextFormatting.WHITE + String.valueOf((current / 2)));
        } else {
            for (int i = 0; i < current / 2; i++) {
                RenderHelper.drawTexturedModalRect(x, y, 43, 9, 9, 9);
                x += 8;
            }
            if (current % 2 != 0) {
                RenderHelper.drawTexturedModalRect(x, y, 25, 9, 9, 9);
            }
        }
    }
}
